import pandas as pd
import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.express as px

app = dash.Dash(__name__)
app.title = "Flipkart Dashboard"

def load_data():
    df = pd.read_csv("flipkart_data.csv")
    return df

app.layout = html.Div([
    html.H1("📦 Flipkart Invoice Dashboard"),
    
    dcc.Graph(id='bar-chart'),
    dcc.Graph(id='pie-chart'),

    # Refresh every 60 seconds
    dcc.Interval(
        id='interval-component',
        interval=60*1000,  # 60 seconds in milliseconds
        n_intervals=0
    )
])

@app.callback(
    [Output('bar-chart', 'figure'),
     Output('pie-chart', 'figure')],
    [Input('interval-component', 'n_intervals')]
)
def update_graphs(n):
    df = load_data()
    fig1 = px.bar(df, x="total_invoice_value", y="end_customer_state_new", color="gst_rate", title="Sales by state")
    fig2 = px.pie(df, names="end_customer_state_new", title="Order Status Distribution")
    return fig1, fig2

if __name__ == "__main__":
    app.run(debug=True)
