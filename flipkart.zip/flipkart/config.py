import os
from dotenv import load_dotenv
load_dotenv()

FLIPKART_API_KEY = os.getenv("FLIPKART_API_KEY")
FLIPKART_API_SECRET = os.getenv("FLIPKART_API_SECRET")
FIREBASE_PROJECT_ID = os.getenv("FIREBASE_PROJECT_ID")
