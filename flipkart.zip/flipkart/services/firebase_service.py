import uuid
import firebase_admin
from firebase_admin import credentials, firestore

try:
    firebase_admin.get_app()
except ValueError:
    cred = credentials.Certificate("firebase_key.json")
    firebase_admin.initialize_app(cred)

db = firestore.client()

def upload_invoices(data, collection_name="flipkart_invoices"):
    for s in data:
        record = {
            "order_id": s.get("orderId", str(uuid.uuid4())),
            "customer": s.get("customer", {}).get("name", "Unknown"),
            "date": s.get("dispatchByDate", ""),
            "item": s.get("orderItems", [{}])[0].get("title", ""),
            "quantity": s.get("orderItems", [{}])[0].get("quantity", 1),
            "amount": s.get("orderItems", [{}])[0].get("priceComponents", {}).get("sellingPrice", 0),
            "status": s.get("shipmentStatus", "Pending")
        }
        db.collection(collection_name).document(record["order_id"]).set(record)
