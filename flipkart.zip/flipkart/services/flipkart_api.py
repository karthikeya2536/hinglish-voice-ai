import requests
from config import FLIPKART_API_KEY, FLIPKART_API_SECRET

BASE_URL = "https://api.flipkart.net/sellers"
TOKEN_URL = "https://api.flipkart.net/oauth-service/oauth/token"

def get_access_token():
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    data = {
        "grant_type": "client_credentials",
        "scope": "Seller_Api",
        "client_id": FLIPKART_API_KEY,
        "client_secret": FLIPKART_API_SECRET
    }
    response = requests.post(TOKEN_URL, headers=headers, data=data)
    response.raise_for_status()
    return response.json().get("access_token")

def fetch_shipments():
    access_token = get_access_token()
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json"
    }
    url = f"{BASE_URL}/v3/shipments?statuses=APPROVED,PACKED,SHIPPED,DELIVERED"
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    return response.json().get("shipments", [])
