from flask import Flask, jsonify
import threading, time
from services.flipkart_api import fetch_shipments
from services.firebase_service import upload_invoices, db

app = Flask(__name__)

@app.route("/data", methods=["GET"])
def get_data():
    docs = db.collection("flipkart_invoices").stream()
    return jsonify([doc.to_dict() for doc in docs])

def scheduler():
    while True:
        try:
            shipments = fetch_shipments()
            upload_invoices(shipments)
            print(f"Fetched and uploaded {len(shipments)} records.")
        except Exception as e:
            print(f"Scheduler error: {e}")
        time.sleep(300)

if __name__ == "__main__":
    threading.Thread(target=scheduler, daemon=True).start()
    app.run(port=5000)
